// This is a dummy export to prevent TypeScript errors
export const isNextJsProject = true
