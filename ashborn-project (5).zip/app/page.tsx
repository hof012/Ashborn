import App from "@/src/App"

// This is a Next.js App Router page component
export default function Home() {
  return <App />
}
